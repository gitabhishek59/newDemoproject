from flask import Flask, render_template, request, redirect, url_for, session
import pandas as pd
from modules.issuer import IssuerModule
from modules.buyer import BuyerModule
from modules.supplier import SupplierModule

app = Flask(__name__)
app.secret_key = 'd89b4c5564ae8195b7c5322f01f9d51f'

# Load the input data
df = pd.read_excel('Input.xlsx')

issuer_module = IssuerModule(df)
buyer_module = BuyerModule(df)
supplier_module = SupplierModule(df)  # Initialize the SupplierModule

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/issuer', methods=['GET', 'POST'])
def issuer_stats():
    if request.method == 'POST':
        issuer_name = request.form['issuer_name']
        top_n = int(request.form['top_n'])
        session['top_n'] = top_n  # Store top_n in session
        issuer_stats = issuer_module.get_issuer_stats(issuer_name, top_n)
        return render_template('issuer_stats.html', issuer_stats=issuer_stats, issuer_name=issuer_name)
    return render_template('issuer_stats.html')

@app.route('/issuer/<issuer_name>/buyer-industry/<buyer_industry>', methods=['GET'])
def show_top_buyers(issuer_name, buyer_industry):
    top_n = session.get('top_n', 5)  # Retrieve top_n from session, default to 5 if not set
    top_buyers = issuer_module.get_top_buyers_by_industry(issuer_name, buyer_industry, 5)
    issuer_stats = issuer_module.get_issuer_stats(issuer_name, top_n)
    return render_template('issuer_stats.html', issuer_stats=issuer_stats, top_buyers=top_buyers, issuer_name=issuer_name, buyer_industry=buyer_industry)

@app.route('/buyer', methods=['GET', 'POST'])
def buyer_stats():
    if request.method == 'POST':
        buyer_name = request.form['buyer_name']
        buyer_stats = buyer_module.get_buyer_stats(buyer_name)
        return render_template('buyer_stats.html', buyer_stats=buyer_stats, buyer_name=buyer_name)
    return render_template('buyer_stats.html')

@app.route('/supplier', methods=['GET', 'POST'])
def supplier_stats():
    if request.method == 'POST':
        supplier_name = request.form['supplier_name']
        supplier_stats = supplier_module.get_supplier_stats(supplier_name)
        if supplier_stats:
            return render_template('supplier_stats.html', supplier_stats=supplier_stats, supplier_name=supplier_name)
        else:
            return render_template('supplier_stats.html', error_message=f"No data found for supplier: {supplier_name}")
    return render_template('supplier_stats.html')

@app.route('/get_buyer_stats/<buyer_name>')
def get_buyer_stats(buyer_name):
    # Get buyer statistics using the BuyerModule
    buyer_stats = buyer_module.get_buyer_stats(buyer_name)
    return render_template('supplier_stats.html', buyer_name=buyer_name, buyer_stats=buyer_stats)

if __name__ == '__main__':
    app.run(debug=True)
