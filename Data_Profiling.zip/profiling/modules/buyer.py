class BuyerModule:
    def __init__(self, df):
        self.df = df

    def get_buyer_stats(self, buyer_name):
        buyer_data = self.df[self.df['Buyer'] == buyer_name]
        total_payment_volume = buyer_data['Payment Volume'].sum()

        # Determine the buyer industry with the highest spending
        buyer_industry_data = buyer_data.groupby('Buyer Industry')['Payment Volume'].sum()
        buyer_industry = buyer_industry_data.idxmax() if not buyer_industry_data.empty else 'N/A'

        # Get the buyer's position within its industry segment
        industry_data = self.df[self.df['Buyer Industry'] == buyer_industry]
        industry_buyer_volume = industry_data.groupby('Buyer')['Payment Volume'].sum()
        industry_buyer_rank = industry_buyer_volume.rank(ascending=False, method='min').to_dict()
        industry_position = industry_buyer_rank.get(buyer_name, 'N/A')

        # Get the number of suppliers associated with the buyer
        number_of_suppliers = buyer_data['Supplier'].nunique()

        # Identify the supplier industry on which the buyer spent the most
        supplier_industry_data = buyer_data.groupby('Supplier Industry')['Payment Volume'].sum()
        top_supplier_industry = supplier_industry_data.idxmax() if not supplier_industry_data.empty else 'N/A'
        top_supplier_industry_percentage = (
            supplier_industry_data.max() / total_payment_volume) * 100 if total_payment_volume > 0 else 0

        buyer_stats = {
            'total_payment_volume': total_payment_volume,
            'buyer_industry': buyer_industry,
            'industry_position': int(industry_position) if industry_position != 'N/A' else 'N/A',
            'number_of_suppliers': number_of_suppliers,
            'top_supplier_industry': top_supplier_industry,
            'top_supplier_industry_percentage': round(top_supplier_industry_percentage, 2),
            'supplier_industry_data': supplier_industry_data.to_dict()  # Supplier industry data for pie chart
        }
        return buyer_stats
