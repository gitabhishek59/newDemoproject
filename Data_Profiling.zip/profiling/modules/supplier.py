class SupplierModule:
    def __init__(self, df):
        self.df = df

    def get_supplier_stats(self, supplier_name):
        supplier_data = self.df[self.df['Supplier'] == supplier_name]

        if supplier_data.empty:
            return None  # Handle case where supplier_name is not found

        # Calculate total payment volume of the supplier
        total_payment_volume = supplier_data['Payment Volume'].sum()

        # Determine the supplier industry
        supplier_industry = supplier_data.iloc[0]['Supplier Industry']  # Assuming all rows have same supplier industry

        # Get the supplier's position within its industry segment
        industry_supplier_volume = self.df[self.df['Supplier Industry'] == supplier_industry].groupby('Supplier')['Payment Volume'].sum()
        industry_supplier_rank = industry_supplier_volume.rank(ascending=False, method='min').to_dict()
        supplier_position = industry_supplier_rank.get(supplier_name, 'N/A')

        # Get the number of unique buyers associated with the supplier
        number_of_buyers = supplier_data['Buyer'].nunique()

        # Identify the buyer industry that has spent the most on this supplier
        buyer_industry_data = supplier_data.groupby('Buyer Industry')['Payment Volume'].sum()
        top_buyer_industry = buyer_industry_data.idxmax() if not buyer_industry_data.empty else 'N/A'
        top_buyer_industry_percentage = (
            buyer_industry_data.max() / total_payment_volume) * 100 if total_payment_volume > 0 else 0

        # Prepare data for other buyer industries pie chart
        other_buyer_industries = buyer_industry_data.to_dict()

        supplier_stats = {
            'total_payment_volume': total_payment_volume,
            'supplier_industry': supplier_industry,
            'supplier_position': int(supplier_position) if supplier_position != 'N/A' else 'N/A',
            'number_of_buyers': number_of_buyers,
            'top_buyer_industry': top_buyer_industry,
            'top_supplier_industry_percentage': round(top_buyer_industry_percentage, 2),
            'other_buyer_industries': other_buyer_industries
        }

        return supplier_stats
